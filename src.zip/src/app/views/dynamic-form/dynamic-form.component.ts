import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormFieldService, FormField } from '../../_services/form-field.service';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss']
})
export class DynamicFormComponent implements OnInit {
  form: FormGroup;
  fields: FormField[] = [];

  constructor(private fb: FormBuilder, private formFieldService: FormFieldService) {
    this.form = this.fb.group({});
  }

  ngOnInit(): void {
    this.formFieldService.fields$.subscribe(fields => {
      this.fields = fields;
      this.form = this.createFormGroup(fields);
    });
  }

  createFormGroup(fields: FormField[]): FormGroup {
    const group: any = {};
    fields.forEach(field => {
      group[field.label] = field.required ? [null, Validators.required] : [null];
    });
    return this.fb.group(group);
  }

  onSubmit() {
    if (this.form.valid) {
      console.log(this.form.value);
      alert('Form submitted successfully!');
    } else {
      alert('Please fill all required fields.');
    }
  }
}
