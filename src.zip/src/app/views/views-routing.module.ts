import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {
  DashboardComponent, ViewsComponent, 
  UserComponent,
  UserFormComponent
} from '.';
import { GuardService } from '../_guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: '',
    component: ViewsComponent,
    children: [
      { path: '', component: DashboardComponent, canActivate: [GuardService] },
      { path: 'dashboard', component: DashboardComponent, canActivate: [GuardService] },

      { path: 'users', component: UserComponent, canActivate: [GuardService], data: { title: 'Users' } },
      { path: 'users/add', component: UserFormComponent, canActivate: [GuardService], data: { title: 'Add User' } },
      { path: 'users/edit/:userId', component: UserFormComponent, canActivate: [GuardService], data: { title: 'Update Users' } },
  
      
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ViewsRoutingModule { }
