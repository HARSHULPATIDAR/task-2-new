/**
 * Generate 10 random no
 */
let counter = 1000; // Initial value for the counter

export function generateSequentialNo() {
    const result = counter;
    counter++; // Increment the counter for the next call
    if (counter > 9999) {
        counter = 1000; // Reset the counter if it goes beyond 9999
    }
    return result;
}
