import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Assets, Regex, RouteNames, LOCAL_KEY, FAICONS } from '../../_constants';
import { MyErrorStateMatcher, setLocalStorage } from '../../helpers';
import { CommonService, UserService } from '../../_services';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup | any;
  matcher = new MyErrorStateMatcher();
  files: any = Assets;
  hidePassword = true;
  faIcon: any = FAICONS;

  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private commonService: CommonService
  ) { }

  ngOnInit(): void {
    this.initializeForm();
  }

  /**
   * Initially load form
   */
  initializeForm() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(Regex.email)]],
      password: ['', Validators.required],
    });
  }

  get loginFG() {
    return this.loginForm.controls;
  }

  togglePasswordVisibility() {
    this.hidePassword = !this.hidePassword;
  }


  /**
   * On submit to login
   */
  onSubmit() {
    if (this.loginForm.value.email == 'test@gmail.com' && this.loginForm.value.password == 'Test@123') {
      this.commonService.toaster({
        success: true,
        message: 'Login successfully'
     });
      setLocalStorage(LOCAL_KEY.TOKEN, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c');
      setTimeout(() => {
        location.href = RouteNames.DASHBOARD;
      }, 600);
    } else {
      this.commonService.toaster({
        success: false,
        message: 'Email or Password is invalid'
      });
    }
  }
}
