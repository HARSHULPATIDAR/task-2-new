import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClientService } from './http.service';
import { API } from '../_constants';

@Injectable({
    providedIn: 'root'
})
export class UserService {

    constructor(
        private httpClientService: HttpClientService
    ) { }

    /**
     * Save user
     * @param req req params
     * @returns res from api
     */
    saveUser(req: any) {
        const url = environment.endpoint + API.SAVE_USER;
        return this.httpClientService.post(url, req);
    }

    /**
     * Get user
     * @param req req params
     * @returns res from api
     */
    getUser(req: any) {
        let url = environment.endpoint + API.GET_USER;
        if (req && req.currentPage) {
            url += `?currentPage=${req.currentPage}&pageSize=${req.pageSize}`;

            if (req.keyword) {
                url += `&keyword=${req.keyword}`;
            }
        }
        if (req?._id) {
            url += `?_id=${req._id}`;
        }
        return this.httpClientService.get(url);
    }

    /**
     * Delete user
     * @param req req params
     * @returns res from api
     */
    deleteUser(req: any) {
        const url = environment.endpoint + API.DELETE_USER;
        return this.httpClientService.post(url, req);
    }

    /**
     * Login user
     * @param req req params
     * @returns res from api
     */
    login(req: any) {
        const url = environment.endpoint + API.LOGIN;
        return this.httpClientService.post(url, req);
    }
}