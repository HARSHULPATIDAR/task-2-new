export enum RoleName {
    ADMIN = 'Admin',
    USER = 'User',
};

export enum RoleID {
    ADMIN = 1,
    USER = 2,
};

export const Roles = [
    { id: RoleID.ADMIN, name: RoleName.ADMIN },
    { id: RoleID.USER, name: RoleName.USER },
];

export const TableCols = [
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    { key: 'phone_no', label: 'Phone No' },
    { key: 'role', label: 'Role' },
];

export const MenuItems = [
    { id: 1, label: 'Dashboard' },
    { id: 4, label: 'User' },
];