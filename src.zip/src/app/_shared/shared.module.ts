import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    ConfirmationDialogComponent, CommonTableComponent,
    PaginationComponent, PageHeaderComponent
} from './index';
import { MaterialModule } from '../material.module';
import { PipeModule } from '../_pipes/pipe.module';
import { DropzoneDirective } from '../_directives';

@NgModule({
    declarations: [
        DropzoneDirective,
        ConfirmationDialogComponent,
        CommonTableComponent,
        PaginationComponent,
        PageHeaderComponent,
    ],
    imports: [
        FormsModule,
        CommonModule,
        ReactiveFormsModule,
        MaterialModule,
        PipeModule
    ],
    entryComponents: [
        ConfirmationDialogComponent,
    ],
    exports: [
        CommonTableComponent,
        PaginationComponent,
        PageHeaderComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class SharedModule { }
