# Dynamic Form Builder

This project is a dynamic form builder implemented in Angular 14. It allows users to add various types of form fields dynamically and submit the form.

## Prerequisites

- Node.js and npm should be installed on your system. You can download them from [here](https://nodejs.org/).

## Setup Instructions

1. **Clone the repository:**

    ```bash
    git clone https://github.com/your-username/dynamic-form-builder.git
    cd dynamic-form-builder
    ```

2. **Install dependencies:**

    ```bash
    npm install
    ```

3. **Run the application:**

    ```bash
    ng serve
    ```

4. Open your browser and navigate to `http://localhost:4200` to see the application in action.

## Project Structure

- `src/app/form-field.service.ts`: Service to manage form fields.
- `src/app/form-builder/form-builder.component.ts`: Component to add form fields dynamically.
- `src/app/dynamic-form/dynamic-form.component.ts`: Component to render and handle the dynamic form.
#   t a s k 2 - a g n u l a r  
 